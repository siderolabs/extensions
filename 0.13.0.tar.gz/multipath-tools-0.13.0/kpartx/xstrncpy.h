#ifndef XSTRNCPY_H_INCLUDED
#define XSTRNCPY_H_INCLUDED
extern void xstrncpy(char *dest, const char *src, size_t n);
#endif
