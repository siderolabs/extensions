#ifndef UXCLNT_H_INCLUDED
#define UXCLNT_H_INCLUDED

int uxclnt(char * inbuf, unsigned int timeout);

#endif
