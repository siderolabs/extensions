#ifndef PIDFILE_H_INCLUDED
#define PIDFILE_H_INCLUDED
int pidfile_create(const char *pidFile, pid_t pid);
#endif

