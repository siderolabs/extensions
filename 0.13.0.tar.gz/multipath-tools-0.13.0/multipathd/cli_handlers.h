#ifndef CLI_HANDLERS_H_INCLUDED
#define CLI_HANDLERS_H_INCLUDED

void init_handler_callbacks(void);

#endif
