#ifndef HWTABLE_H_INCLUDED
#define HWTABLE_H_INCLUDED

int setup_default_hwtable (vector hw);

#endif /* HWTABLE_H_INCLUDED */
