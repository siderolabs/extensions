/*
 * Copyright (c) 2005 Christophe Varoqui
 */
#include <string.h>

#include "defaults.h"

const char * const default_partition_delim = DEFAULT_PARTITION_DELIM;
