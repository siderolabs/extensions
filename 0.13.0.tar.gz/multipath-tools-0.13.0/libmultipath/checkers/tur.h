#ifndef TUR_H_INCLUDED
#define TUR_H_INCLUDED

int tur (struct checker *);
int tur_init (struct checker *);
void tur_free (struct checker *);

#endif /* TUR_H_INCLUDED */
