#ifndef HP_SW_H_INCLUDED
#define HP_SW_H_INCLUDED

int hp_sw (struct checker *);
int hp_sw_init (struct checker *);
void hp_sw_free (struct checker *);

#endif /* HP_SW_H_INCLUDED */
