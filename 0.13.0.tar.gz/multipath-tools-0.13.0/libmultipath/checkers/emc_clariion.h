#ifndef EMC_CLARIION_H_INCLUDED
#define EMC_CLARIION_H_INCLUDED

int emc_clariion (struct checker *);
int emc_clariion_init (struct checker *);
void emc_clariion_free (struct checker *);

#endif /* EMC_CLARIION_H_INCLUDED */
