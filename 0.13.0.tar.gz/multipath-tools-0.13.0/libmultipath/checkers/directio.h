#ifndef DIRECTIO_H_INCLUDED
#define DIRECTIO_H_INCLUDED

int directio (struct checker *);
int directio_init (struct checker *);
void directio_free (struct checker *);

#endif /* DIRECTIO_H_INCLUDED */
