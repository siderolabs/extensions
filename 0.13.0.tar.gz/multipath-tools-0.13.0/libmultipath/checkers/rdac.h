#ifndef RDAC_H_INCLUDED
#define RDAC_H_INCLUDED

int rdac(struct checker *);
int rdac_init(struct checker *);
void rdac_free(struct checker *);

#endif /* RDAC_H_INCLUDED */
