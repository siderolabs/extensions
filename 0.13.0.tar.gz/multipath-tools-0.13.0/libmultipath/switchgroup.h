#ifndef SWITCHGROUP_H_INCLUDED
#define SWITCHGROUP_H_INCLUDED

void path_group_prio_update (struct pathgroup * pgp);
int select_path_group (struct multipath * mpp);

#endif
